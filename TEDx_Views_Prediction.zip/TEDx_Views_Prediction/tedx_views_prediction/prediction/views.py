from django.shortcuts import render
import numpy as np
import pickle

# Load the model
model = pickle.load(open('model.pkl', 'rb'))

def home(request):
    return render(request, 'index.html')

def predict(request):
    if request.method == 'POST':
        features = [int(x) for x in request.POST.values()]
        final_features = [np.array(features)]
        prediction = model.predict(final_features)
        output = prediction[0]
        return render(request, 'index.html', {'prediction_text': f'Predicted Views: {output}'})
    return render(request, 'index.html')