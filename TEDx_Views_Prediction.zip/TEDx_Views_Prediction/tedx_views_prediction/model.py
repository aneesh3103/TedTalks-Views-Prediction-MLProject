import pandas as pd
from sklearn.linear_model import LinearRegression
import pickle

# Sample data - replace with your dataset
data = {
    'feature1': [25, 35, 45, 50, 23, 43, 54, 32, 34, 67],
    'feature2': [200, 230, 250, 270, 190, 210, 240, 220, 225, 260],
    'views': [1000, 1500, 2000, 2500, 800, 1200, 1800, 1100, 1300, 2700]
}
df = pd.DataFrame(data)

X = df[['feature1', 'feature2']]
y = df['views']

model = LinearRegression()
model.fit(X, y)

# Save the model
pickle.dump(model, open('model.pkl', 'wb'))